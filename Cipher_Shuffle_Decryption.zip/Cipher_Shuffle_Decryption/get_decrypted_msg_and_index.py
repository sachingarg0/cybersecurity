message = input("Enter Encrypted Code to Decrypt: ")
first = input("Enter First index index[0]: ")
second = input("Enter First index index[1]: ")
index = [second, first]